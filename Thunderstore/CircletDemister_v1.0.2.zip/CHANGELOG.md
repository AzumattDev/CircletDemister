| `Version` | `Update Notes`                                                                                                            |
|-----------|---------------------------------------------------------------------------------------------------------------------------|
| 1.0.2     | - Courtesy Update for Valheim 0.217.46. Just bumping the version and updating the last updated date. Nothing to see here. |
| 1.0.1     | - Update for Valheim 0.217.22                                                                                             |
| 1.0.0     | - Initial Release (compatible with Mistlands only! Will not work with any earlier versions of Valheim.)                   |